package com.zyapaar.pizzashop.pizzashop;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PizzaShopApplicationTests {

	@Test
	void contextLoads() {
	}

}
