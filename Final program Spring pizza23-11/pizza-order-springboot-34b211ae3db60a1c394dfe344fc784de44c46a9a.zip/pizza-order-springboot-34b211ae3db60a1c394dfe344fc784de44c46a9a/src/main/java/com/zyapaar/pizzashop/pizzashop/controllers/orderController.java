package com.zyapaar.pizzashop.pizzashop.controllers;

import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.fasterxml.jackson.databind.node.ObjectNode;

@RestController
public class orderController {


    @PostMapping("order")
    public String placeorder(@RequestBody String pizza){
        String returnString = "Smit";

        return returnString;
    }
    
    // @PostMapping("order/{shopid}")

    // public String placeorder(@RequestBody String pizza, @PathVariable String shopid, @RequestBody String size,@RequestBody String category){
    //     String returnString = "";
    //     returnString+=pizza+"\n";
    //     returnString+=shopid+"\n";
    //     returnString+=size+"\n";
    //     returnString+=category+"\n";

    //     return returnString;
    // }
    
}
