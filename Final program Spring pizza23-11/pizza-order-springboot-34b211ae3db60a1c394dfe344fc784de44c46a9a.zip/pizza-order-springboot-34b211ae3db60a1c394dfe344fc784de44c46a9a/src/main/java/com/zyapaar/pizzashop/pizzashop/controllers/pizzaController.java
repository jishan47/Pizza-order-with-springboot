package com.zyapaar.pizzashop.pizzashop.controllers;

import java.util.ArrayList;

import javax.annotation.PostConstruct;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.zyapaar.pizzashop.pizzashop.services.pizzaServices;

@RestController
public class pizzaController {

    @GetMapping("pizza")
    public ArrayList<String> getAll(){
        return pizzaServices.getAll();
     }

     @GetMapping(value="pizza", params = "category")
     public ArrayList<String> getAll(@RequestParam String category){
        return pizzaServices.getAll(category);
     }

     @GetMapping("pizza/{category}")
    
     public ArrayList<String> getAllbypathvariable(@PathVariable String category){
        return pizzaServices.getAll(category);
     }

     @PostMapping("pizza")

     public ArrayList<String> getallbypost(@RequestBody String category){
            return pizzaServices.getAll(category);
     }
}
