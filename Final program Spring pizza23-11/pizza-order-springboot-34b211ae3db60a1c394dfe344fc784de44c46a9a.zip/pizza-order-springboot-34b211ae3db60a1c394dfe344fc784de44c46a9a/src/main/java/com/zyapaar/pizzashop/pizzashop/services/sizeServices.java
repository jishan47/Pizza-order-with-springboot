package com.zyapaar.pizzashop.pizzashop.services;

import java.util.ArrayList;

public class sizeServices {

    public static ArrayList<String> getAll(){
        ArrayList<String>  size = new ArrayList<>();
        size.add("Regular");
        size.add("Medium");
        size.add("Large");
        return size;
        

    }
    
    
}
