package com.zyapaar.pizzashop.pizzashop.services;

import java.util.ArrayList;

public class pizzaServices {

    public static ArrayList<String> getAll() {
        ArrayList<String> pizza = new ArrayList<String>();
        pizza.add("Tomchi");
        pizza.add("Caponito");
        pizza.add("Red Indian");
        pizza.add("Party Lovers");
        pizza.add("American Heat");
        pizza.add("Re-Union");
        return pizza;
    }

    public static ArrayList<String> getAll(String category) {

        ArrayList<String> pizza = new ArrayList<String>();
        if (category.equals("Regular")) {
            pizza.add("Tomchi");
            pizza.add("Caponito");
        } else if (category.equals("Premium")) {
            pizza.add("Red Indian");
            pizza.add("Party Lovers");
        } else {
            pizza.add("American Heat");
            pizza.add("Re-Union");
        }
        return pizza;

    }
}
